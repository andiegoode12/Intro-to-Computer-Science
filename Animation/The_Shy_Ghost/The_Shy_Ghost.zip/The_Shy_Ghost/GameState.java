public enum GameState
{ //<>//
  WELCOME,
  RUNNING,
  CONTINUE, //<>//
  YOULOSE,
  SUMMARY
}